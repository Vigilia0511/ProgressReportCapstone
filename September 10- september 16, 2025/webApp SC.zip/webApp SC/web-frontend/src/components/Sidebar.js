import React from "react";
import "../assets/css/styles.css";

function Sidebar() {
  return (
    <aside className="sidebar">
      <h2 className="logo">Capstone</h2>
      <ul className="menu">
        <li><a href="/dashboard">Dashboard</a></li>
        <li><a href="/users">Users</a></li>
        <li><a href="/reports">Reports</a></li>
        <li><a href="/settings">Settings</a></li>
      </ul>
    </aside>
  );
}

export default Sidebar;
