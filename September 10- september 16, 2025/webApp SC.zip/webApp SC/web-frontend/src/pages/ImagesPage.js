import React, { useState, useEffect, useRef } from "react";
import "../assets/css/styles1.css";

function ImagesPage() {
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [liveView, setLiveView] = useState(false);
  const [doorLock, setDoorLock] = useState(false);
  const [images, setImages] = useState([]);
  const [fullscreenImage, setFullscreenImage] = useState(null);
  const sidebarRef = useRef(null);

  // Apply/remove body dark mode
  useEffect(() => {
    document.body.classList.toggle("dark-body", darkMode);
    return () => document.body.classList.remove("dark-body");
  }, [darkMode]);

  // Close sidebar when clicking outside or pressing Escape
  useEffect(() => {
    function handleOutsideClick(e) {
      if (sidebarOpen && sidebarRef.current && !sidebarRef.current.contains(e.target)) {
        setSidebarOpen(false);
      }
    }
    function handleEscape(e) {
      if (e.key === "Escape") setSidebarOpen(false);
    }
    document.addEventListener("mousedown", handleOutsideClick);
    document.addEventListener("keydown", handleEscape);
    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
      document.removeEventListener("keydown", handleEscape);
    };
  }, [sidebarOpen]);

  // Disable body scroll when sidebar is open
  useEffect(() => {
    document.body.style.overflow = sidebarOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [sidebarOpen]);

  // Fetch images
  useEffect(() => {
    fetch("http://localhost/CAPSTONE_BACKEND/fetch_images.php")
      .then((res) => res.json())
      .then((data) => setImages(data))
      .catch(() => setImages([]));
  }, []);

  // Toggle door lock
  const handleDoorLock = async (e) => {
    const state = e.target.checked ? "on" : "off";
    setDoorLock(e.target.checked);
    try {
      const formData = new URLSearchParams();
      formData.append("switch", state);
      const response = await fetch("http://192.168.176.237:5000/control_solenoid", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: formData,
      });
      const jsonResponse = await response.json();
      if (jsonResponse.status !== "success") throw new Error(jsonResponse.message || "Unknown error");
    } catch (error) {
      alert(`Error toggling door lock:\n${error.message}`);
      setDoorLock(!doorLock);
    }
  };

  const handleDownload = (src, id) => {
    const a = document.createElement("a");
    a.href = src;
    a.download = `captured_${id}.jpg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this image?")) {
      fetch(`http://localhost/CAPSTONE_BACKEND/fetch_images.php?delete=${encodeURIComponent(id)}`)
        .then((res) => res.json())
        .then((result) => {
          if (result.success) {
            setImages((prev) => prev.filter((img) => img.id !== id));
            alert("Image deleted successfully.");
          } else {
            alert("Failed to delete image: " + (result.message || "Unknown error"));
          }
        })
        .catch((err) => alert("Error deleting image: " + err.message));
    }
  };

  return (
    <div>
      {/* Header */}
      <div className="header">
        <div className="logo">
          <img src="/assets/image/logo.png" alt="Logo" />
        </div>
        <img
          src="/assets/image/menu.png"
          className="menu-icon"
          alt="Menu"
          onClick={() => setSidebarOpen(true)}
        />
      </div>

      {/* Controls */}
      <div className="controls">
        <div className="toggle-label">
          <label>OPEN DOOR LOCK</label>
          <label className="toggle-switch">
            <input type="checkbox" checked={doorLock} onChange={handleDoorLock} />
            <span className="slider"></span>
          </label>
        </div>
        <button className="live-view-btn" onClick={() => setLiveView(true)}>
          LIVE VIEW
        </button>
      </div>

      {/* Live View */}
      {liveView && (
        <div
          id="liveViewContainer"
          style={{
            display: "flex",
            position: "fixed",
            top: 0,
            left: 0,
            width: "100vw",
            height: "100vh",
            background: "rgba(255,255,255,0.85)",
            zIndex: 10000,
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            gap: "15px",
            padding: "20px",
            boxSizing: "border-box",
          }}
        >
          <button
            id="closeLiveView"
            style={{
              position: "fixed",
              top: 20,
              right: 20,
              background: "#ff4444",
              color: "white",
              border: "none",
              fontSize: "2rem",
              width: 44,
              height: 44,
              borderRadius: "50%",
              cursor: "pointer",
              zIndex: 11000,
              lineHeight: "40px",
              textAlign: "center",
              padding: 0,
            }}
            onClick={() => setLiveView(false)}
          >
            ×
          </button>
          <img
            src="http://192.168.137.135:5000/video_feed"
            alt="Live Video Feed"
            style={{
              maxWidth: "95vw",
              maxHeight: "80vh",
              borderRadius: "8px",
              boxShadow: "0 0 20px rgba(0,0,0,0.3)",
            }}
          />
        </div>
      )}

      {/* Captured Images */}
      <div className="section-title">CAPTURED IMAGES</div>
      <div className="image-list" id="imageList">
        {images.length === 0 ? (
          <p>Error loading images.</p>
        ) : (
          images.map((item) => (
            <div className="image-card" key={item.id}>
              <img src={item.image} alt="Captured" onClick={() => setFullscreenImage(item.image)} />
              <div className="timestamp">{item.timestamp}</div>
              <button
                className="icon-button download-btn"
                title="Download"
                onClick={() => handleDownload(item.image, item.id)}
              >
                <img src="/assets/image/download.png" alt="Download" />
              </button>
              <button
                className="icon-button delete-btn"
                title="Delete"
                onClick={() => handleDelete(item.id)}
              >
                <img src="/assets/image/delete.png" alt="Delete" />
              </button>
            </div>
          ))
        )}
      </div>

      {/* Fullscreen Image */}
      {fullscreenImage && (
        <div
          id="fullscreenOverlay"
          style={{
            display: "flex",
            position: "fixed",
            top: 0,
            left: 0,
            width: "100vw",
            height: "100vh",
            background: "rgba(0,0,0,0.8)",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 20000,
          }}
          onClick={(e) => {
            if (e.target.id === "fullscreenOverlay") setFullscreenImage(null);
          }}
        >
          <img
            id="fullscreenImage"
            src={fullscreenImage}
            style={{ maxWidth: "90vw", maxHeight: "90vh" }}
            alt="Fullscreen"
          />
        </div>
      )}

  {/* Sidebar */}
  <nav ref={sidebarRef} className={`sidebar ${sidebarOpen ? "visible" : ""}`} aria-hidden={!sidebarOpen}>
        <div className="sidebar-header">
          <img src="/assets/image/profile.png" alt="User Icon" className="user-icon" />
          <p>
            Welcome, <strong>ADMIN</strong>
          </p>
        </div>
        <a href="/allnotif" className="btn-link">
          <img src="/assets/image/home.png" className="sidebar-icon" alt="" /> Home
        </a>
        <a href="/approval" className="btn-link">
          <img src="/assets/image/approval.png" className="sidebar-icon" alt="" /> Approval
        </a>
        <a href="/images" className="btn-link">
          <img src="/assets/image/picture.png" className="sidebar-icon" alt="" /> Image
        </a>

        <button
          onClick={() => setSettingsOpen(!settingsOpen)}
          aria-expanded={settingsOpen}
          aria-controls="settingsDropdown"
        >
          <img src="/assets/image/settings.png" className="sidebar-icon" alt="" /> Settings
          <svg
            className={`dropdown-arrow ${settingsOpen ? "open" : ""}`}
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
          >
            <path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z" />
          </svg>
        </button>

        <div className={`settings-dropdown ${settingsOpen ? "open" : ""}`}>
          <div className="toggle-label">
            <label htmlFor="darkModeToggle">Dark Mode</label>
            <label className="toggle-switch">
              <input
                type="checkbox"
                id="darkModeToggle"
                checked={darkMode}
                onChange={() => setDarkMode((d) => !d)}
              />
              <span className="slider"></span>
            </label>
          </div>
          <div className="toggle-label">
            <label htmlFor="biometricToggle">Enable Biometric</label>
            <label className="toggle-switch">
              <input type="checkbox" id="biometricToggle" defaultChecked />
              <span className="slider"></span>
            </label>
          </div>
        </div>

        <button
          onClick={async () => {
            if (window.confirm("Are you sure you want to log out?")) {
              try {
                await fetch("http://localhost/CAPSTONE_BACKEND/logout.php", {
                  method: "GET",
                  credentials: "include",
                });
                window.location.replace("/");
                window.history.pushState(null, "", "/");
                window.onpopstate = function () {
                  window.location.replace("/");
                };
              } catch {
                alert("Logout failed. Please check your backend server.");
              }
            }
          }}
        >
          <img src="/assets/image/logout.png" className="sidebar-icon" alt="" /> Logout
        </button>
      </nav>

  {/* Overlay (visual backdrop; also clickable) */}
  {sidebarOpen && <div className="overlay" onClick={() => setSidebarOpen(false)} />}
    </div>
  );
}

export default ImagesPage;
