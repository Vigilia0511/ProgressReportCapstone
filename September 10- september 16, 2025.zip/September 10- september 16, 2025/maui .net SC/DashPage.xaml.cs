﻿using Microsoft.Maui.Controls;

namespace testdatabase
{
    public partial class DashPage : ContentPage
    {
        public DashPage()
        {
            InitializeComponent();
        }
    }
}
