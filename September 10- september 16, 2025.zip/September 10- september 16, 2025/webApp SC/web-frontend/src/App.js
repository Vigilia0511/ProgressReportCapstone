import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import LoginPage from "./pages/LoginPage";
import AllNotif from "./pages/Allnotif";
import ApprovalPage from "./pages/ApprovalPage";
import ImagesPage from "./pages/ImagesPage";
import UserReg from "./pages/UserReg";
import UserLog from "./pages/UserLog"; // Import the UserLog component

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/allnotif" element={<AllNotif />} />
        <Route path="/approval" element={<ApprovalPage />} />
        <Route path="/images" element={<ImagesPage />} />
        <Route path="/userreg" element={<UserReg />} />
        <Route path="/userlog" element={<UserLog />} /> {/* Add this route */}
      </Routes>
    </Router>
  );
}

export default App;
