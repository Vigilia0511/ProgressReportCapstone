import React from "react";
import "../assets/css/styles.css";

function Header() {
  return (
    <header className="header">
      <h1>Admin Dashboard</h1>
      <div className="user-info">
        <span>👤 Admin</span>
      </div>
    </header>
  );
}

export default Header;
