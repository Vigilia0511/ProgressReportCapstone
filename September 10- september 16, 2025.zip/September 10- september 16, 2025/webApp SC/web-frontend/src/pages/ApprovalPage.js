import React, { useState, useEffect, useRef } from "react";

export default function Approve() {
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const sidebarRef = useRef(null);

  // Fetch users from backend
  const fetchUsers = () => {
    setLoading(true);
    fetch("http://localhost/CAPSTONE_BACKEND/get_users.php")
      .then((res) => res.json())
      .then((data) => {
        setUsers(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch((err) => {
        console.error("fetchUsers error:", err);
        setUsers([]);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Close sidebar when clicking outside the sidebar element
  useEffect(() => {
    function handleOutsideClick(e) {
      if (sidebarOpen && sidebarRef.current && !sidebarRef.current.contains(e.target)) {
        setSidebarOpen(false);
      }
    }

    function handleEscape(e) {
      if (e.key === "Escape") setSidebarOpen(false);
    }

    document.addEventListener("mousedown", handleOutsideClick);
    document.addEventListener("keydown", handleEscape);
    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
      document.removeEventListener("keydown", handleEscape);
    };
  }, [sidebarOpen]);

  // Disable body scroll when sidebar is open (optional, improves UX)
  useEffect(() => {
    document.body.style.overflow = sidebarOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [sidebarOpen]);

  // Toggle user approval status (Allow/Disallow)
  const toggleStatus = async (index) => {
    const user = users[index];
    if (!user) return;
    // Normalize is_approved (handles "0"/"1"/0/1/true/false)
    const currentlyApproved = Number(user.is_approved) === 1 || user.is_approved === true;
    const newStatus = currentlyApproved ? 0 : 1;

    try {
      const res = await fetch("http://localhost/CAPSTONE_BACKEND/update_status.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `name=${encodeURIComponent(user.username)}&status=${newStatus}`,
      });
      const text = await res.text();
      console.log("update_status response:", text);
      fetchUsers(); // Refresh user list after update
    } catch (err) {
      console.error("toggleStatus error:", err);
      alert("Error updating status. Please try again.");
    }
  };

  const isApproved = (u) => Number(u?.is_approved) === 1 || u?.is_approved === true;

  return (
    <div
      className="app-container"
      style={{
        background: darkMode ? "#121212" : "#f4f6f8",
        minHeight: "100vh",
      }}
    >
      {/* Header */}
      <header className="header">
        <div className="logo">
          <img src="/assets/image/logo.png" alt="Logo" />
        </div>
        <img
          src="/assets/image/menu.png"
          className="menu-icon"
          alt="Menu"
          onClick={() => setSidebarOpen(true)}
        />
      </header>

      {/* Content */}
      <main className="content">
        <div className="panel">
          <h2>User Approval Panel</h2>
          {loading ? (
            <div style={{ textAlign: "center", padding: "20px" }}>Loading...</div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u, i) => (
                  <tr key={i}>
                    <td data-label="Name">{u.username}</td>
                    <td data-label="Status">
                      <span className={"status " + (isApproved(u) ? "status-approved" : "status-denied")}>
                        {isApproved(u) ? "✔ Approved" : "✖ Not Approved"}
                      </span>
                    </td>
                    <td data-label="Action">
                      <button
                        className={`btn ${isApproved(u) ? "disallow-btn" : "approve-btn"}`}
                        onClick={() => toggleStatus(i)}
                      >
                        {isApproved(u) ? "Disallow" : "Approve"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </main>

      {/* Sidebar */}
      <nav ref={sidebarRef} className={`sidebar ${sidebarOpen ? "visible" : ""}`} aria-hidden={!sidebarOpen}>
        <div className="sidebar-header">
          <img src="/assets/image/profile.png" alt="User Icon" className="user-icon" />
          <p>
            Welcome, <strong>ADMIN</strong>
          </p>
        </div>

        <a href="/allnotif" className="btn-link">
          <img src="/assets/image/home.png" className="sidebar-icon" alt="" /> Home
        </a>
        <a href="/approval" className="btn-link">
          <img src="/assets/image/approval.png" className="sidebar-icon" alt="" /> Approval
        </a>
        <a href="/images" className="btn-link">
          <img src="/assets/image/picture.png" className="sidebar-icon" alt="" /> Image
        </a>

        {/* Settings Dropdown */}
        <button
          onClick={() => setSettingsOpen(!settingsOpen)}
          aria-expanded={settingsOpen}
          aria-controls="settingsDropdown"
        >
          <img src="/assets/image/settings.png" className="sidebar-icon" alt="" /> Settings
          <svg
            className={`dropdown-arrow ${settingsOpen ? "open" : ""}`}
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
          >
            <path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z" />
          </svg>
        </button>

        <div id="settingsDropdown" className={`settings-dropdown ${settingsOpen ? "open" : ""}`}>
          <div className="toggle-label">
            <label htmlFor="darkModeToggle">Dark Mode</label>
            <label className="toggle-switch">
              <input
                type="checkbox"
                id="darkModeToggle"
                checked={darkMode}
                onChange={() => setDarkMode(!darkMode)}
              />
              <span className="slider"></span>
            </label>
          </div>
          <div className="toggle-label">
            <label htmlFor="biometricToggle">Enable Biometric</label>
            <label className="toggle-switch">
              <input type="checkbox" id="biometricToggle" defaultChecked />
              <span className="slider"></span>
            </label>
          </div>
        </div>

        <button
          onClick={async () => {
            if (window.confirm("Are you sure you want to log out?")) {
              try {
                await fetch("http://localhost/CAPSTONE_BACKEND/logout.php", {
                  method: "GET",
                  credentials: "include",
                });
                window.location.replace("/");
              } catch (error) {
                console.error("logout error:", error);
                alert("Logout failed. Please check your backend server and try again.");
              }
            }
          }}
        >
          <img src="/assets/image/logout.png" className="sidebar-icon" alt="" /> Logout
        </button>
      </nav>

      {/* Overlay (visual backdrop; also clickable) */}
      {sidebarOpen && <div className="overlay" onClick={() => setSidebarOpen(false)} />}

      {/* Styles */}
      <style>{`
        .app-container { min-height: 100vh; }
        .header { 
          background: linear-gradient(to right, #2980b9, #6dd5fa);
          color: white; padding: 10px 20px; 
          display: flex; justify-content: space-between; 
          align-items: center; position: sticky; top: 0; z-index: 100;
        }
        .logo img { width: 40px; }
        .menu-icon { width: 30px; cursor: pointer; }
        .content { padding: 20px; display: flex; justify-content: center; }
        .panel { background: white; padding: 20px; max-width: 900px; width: 100%;
          border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        h2 { text-align: center; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; border-bottom: 1px solid #ddd; }
        th { background: #f0f0f0; text-align: left; }
        .status-approved { color: green; font-weight: bold; }
        .status-denied { color: red; font-weight: bold; }
        .btn { padding: 8px 16px; border-radius: 20px; color: white; font-size: 14px; cursor: pointer; border: none; }
        .approve-btn { background: green; }
        .disallow-btn { background: red; }

        /* overlay/backdrop */
        .overlay {
          position: fixed;
          top: 0; left: 0;
          width: 100%; height: 100%;
          background: rgba(0,0,0,0.5);
          z-index: 1000; /* below the sidebar which is 1100 */
        }

        /* sidebar */
        .sidebar {
          position: fixed;
          top: 0; right: 0;
          width: 300px; height: 100%;
          background: #2A6FA4;
          padding: 20px;
          transform: translateX(100%);
          transition: transform 0.28s cubic-bezier(.2,.8,.2,1);
          z-index: 1100; /* above overlay */
          color: white;
          display: flex; flex-direction: column; gap: 10px;
          box-shadow: -8px 0 16px rgba(0,0,0,0.12);
        }
        .sidebar.visible { transform: translateX(0); }
        .sidebar-header { text-align: center; margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.18); padding-bottom: 15px; }
        .user-icon { width: 60px; height: 60px; border-radius: 50%; margin-bottom: 10px; }
        .btn-link { display: flex; align-items: center; gap: 8px; padding: 10px; border-radius: 6px; color: white; text-decoration: none; }
        .btn-link:hover { background: #0056b3; }
        .sidebar-icon { width: 18px; opacity: 0.95; }

        .dropdown-arrow { margin-left: auto; width: 16px; transition: transform 0.25s ease; }
        .dropdown-arrow.open { transform: rotate(90deg); }
        .settings-dropdown { overflow: hidden; max-height: 0; transition: max-height 0.28s ease; }
        .settings-dropdown.open { max-height: 220px; padding: 10px 0; }

        .toggle-switch { position: relative; display: inline-block; width: 50px; height: 24px; }
        .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background: #ccc; border-radius: 24px; transition: .4s; }
        .slider:before { content: ""; position: absolute; height: 18px; width: 18px; left: 3px; bottom: 3px; background: white; border-radius: 50%; transition: .4s; }
        input:checked + .slider { background: #4caf50; }
        input:checked + .slider:before { transform: translateX(26px); }

        /* dark mode overrides */
        .dark .app-container { background: #121212; color: #eee; }
        .dark .panel { background: #1e1e1e; color: #eee; }
        .dark .header { background: linear-gradient(to right, #222, #555); }
        .dark table { background: #2c2c2c; }
        .dark th, .dark td { border-color: #444; }
      `}</style>
    </div>
  );
}
