import React, { useState, useEffect } from "react";

function arrayBufferToBase64(buffer) {
  let binary = "";
  const bytes = new Uint8Array(buffer);
  for (let b of bytes) {
    binary += String.fromCharCode(b);
  }
  return window.btoa(binary);
}

function UserLog() {
  const [latestUser, setLatestUser] = useState("No user registered");
  const [error, setError] = useState("");
  const [biometricSuccess, setBiometricSuccess] = useState(false);

  useEffect(() => {
    // Fetch the latest registered user from backend session
    fetch("http://localhost/CAPSTONE_BACKEND/get_latest_user.php", {
      method: "GET",
      credentials: "include",
    })
      .then((res) => res.json())
      .then((data) => {
        setLatestUser(data.latestUser || "No user registered");
      })
      .catch(() => {
        setLatestUser("No user registered");
      });
  }, []);

  const runBiometricAuth = async () => {
    setError("");
    if (!window.PublicKeyCredential) {
      setError("WebAuthn is not supported in this browser.");
      return;
    }

    const challenge = new Uint8Array(32);
    window.crypto.getRandomValues(challenge);

    try {
      const credential = await navigator.credentials.create({
        publicKey: {
          challenge: challenge,
          rp: { name: "Biometric Demo" },
          user: {
            id: new Uint8Array(16),
            name: latestUser,
            displayName: "Biometric User",
          },
          pubKeyCredParams: [{ type: "public-key", alg: -7 }],
          authenticatorSelection: {
            authenticatorAttachment: "platform",
            userVerification: "required",
          },
          timeout: 60000,
          attestation: "none",
        },
      });

      // Prepare credential data for backend
      const credentialJson = {
        id: credential.id,
        rawId: arrayBufferToBase64(credential.rawId),
        type: credential.type,
        response: {
          clientDataJSON: arrayBufferToBase64(credential.response.clientDataJSON),
          attestationObject: arrayBufferToBase64(credential.response.attestationObject),
        },
      };

      // POST credential to backend for registration & approval check
      const resp = await fetch("http://localhost/CAPSTONE_BACKEND/registerBiometric.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: latestUser,
          credential: credentialJson,
        }),
      });

      const data = await resp.json();

      if (data.isApproved) {
        setBiometricSuccess(true);
        setTimeout(() => {
          window.location.replace("/allnotif");
        }, 2000);
      } else {
        setError("Account not approved. Contact admin.");
      }
    } catch (err) {
      setError("Biometric authentication failed or was canceled.");
    }
  };

  return (
    <div className="container">
      <style>{`
        body {
          background: linear-gradient(135deg, #667eea, #764ba2);
          font-family: 'Inter', sans-serif;
          min-height: 100vh;
          display: flex;
          justify-content: center;
          align-items: center;
          padding: 20px;
        }
        .container {
          background: white;
          border-radius: 20px;
          box-shadow: 0 8px 20px rgba(0,0,0,0.15);
          max-width: 480px;
          width: 100%;
          padding: 32px;
          text-align: center;
        }
        .logo-container {
          background-color: #f1f5f9;
          border-radius: 60px;
          padding: 20px;
          margin: 0 auto 24px;
          width: 100px;
          display: flex;
          justify-content: center;
          align-items: center;
        }
        .logo-container img {
          height: 80px;
          width: 80px;
        }
        .user-info {
          background: #f7fafc;
          padding: 16px;
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          display: flex;
          gap: 12px;
          margin-bottom: 24px;
          justify-content: center;
          align-items: center;
        }
        .user-icon {
          background: #667eea;
          color: white;
          font-size: 16px;
          padding: 6px;
          width: 32px;
          height: 32px;
          border-radius: 16px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .user-details label {
          display: block;
        }
        .user-details .name {
          font-size: 14px;
          font-weight: bold;
          color: #2d3748;
        }
        .user-details .status {
          font-size: 13px;
          color: #718096;
        }
        #error-message {
          color: red;
          margin-bottom: 16px;
        }
        #authButton {
          background: #667eea;
          color: white;
          font-weight: bold;
          padding: 12px;
          border: none;
          border-radius: 12px;
          width: 100%;
          cursor: pointer;
          font-size: 16px;
          margin-bottom: 24px;
        }
        .register-link {
          font-size: 15px;
        }
        .register-link a {
          color: #667eea;
          font-weight: bold;
          text-decoration: none;
        }
        #registrationForm {
          display: none;
        }
      `}</style>
      <div className="logo-container">
        <img src="/assets/image/logo.png" alt="Logo" />
      </div>
      <h1>Welcome Back</h1>
      <p>Sign in with your biometric</p>
      <div id="error-message">{error}</div>
      <div className="user-info">
        <div className="user-icon">👤</div>
        <div className="user-details">
          <label className="name">Current User</label>
          <label className="status">{latestUser}</label>
        </div>
      </div>
      {!biometricSuccess && (
        <button id="authButton" onClick={runBiometricAuth}>
          Register Biometric
        </button>
      )}
      {biometricSuccess && (
        <form id="registrationForm">
          <p>Biometric registered successfully! Redirecting...</p>
        </form>
      )}
      <div className="register-link">
        <span>Don't have an account? </span>
        <a href="/userreg">Register</a>
      </div>
    </div>
  );
}
export default UserLog;