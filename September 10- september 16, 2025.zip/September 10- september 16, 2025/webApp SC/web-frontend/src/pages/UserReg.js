import React, { useState } from "react";

function UserReg() {
  const [biometricSuccess, setBiometricSuccess] = useState(false);
  const [fullname, setFullname] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const handleBiometricAuth = async () => {
    if (!window.PublicKeyCredential) {
      setError("WebAuthn is not supported in this browser.");
      return;
    }

    const challenge = new Uint8Array(32);
    window.crypto.getRandomValues(challenge);

    try {
      const credential = await navigator.credentials.create({
        publicKey: {
          challenge: challenge,
          rp: { name: "Biometric Demo" },
          user: {
            id: new Uint8Array(16),
            name: "biouser",
            displayName: "Biometric User",
          },
          pubKeyCredParams: [{ type: "public-key", alg: -7 }],
          authenticatorSelection: {
            authenticatorAttachment: "platform",
            userVerification: "required",
          },
          timeout: 60000,
          attestation: "none",
        },
      });

      setBiometricSuccess(true);
      setError("");
    } catch (err) {
      setError("Biometric authentication failed or was canceled.");
      setBiometricSuccess(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (fullname.trim().length < 2) {
      setError("Please enter a valid full name (at least 2 characters).");
      return;
    }

    try {
      const res = await fetch("http://localhost/CAPSTONE_BACKEND/userreg.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `fullname=${encodeURIComponent(fullname)}`,
        credentials: "include",
      });
      const text = await res.text();

      if (text.includes("already registered")) {
        setError("This name is already registered. Please use another or contact support.");
      } else if (text.includes("Failed to register")) {
        setError("Failed to register. Please try again.");
      } else if (text.includes("Database connection failed")) {
        setError("Database connection failed.");
      } else {
        setSuccess("Registration successful! Redirecting...");
        setTimeout(() => {
          window.location.replace("/userlog");
        }, 1500);
      }
    } catch {
      setError("Network error. Please try again.");
    }
  };

  return (
    <div className="container">
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body, html { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); height: 100%; }
        .container { display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 16px; }
        .card { background: #fff; border-radius: 20px; padding: 32px 24px; box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2); width: 100%; max-width: 420px; text-align: center; }
        .logo-container img { width: 100px; height: 100px; background-color: #f1f5f9; border-radius: 50%; padding: 20px; margin-bottom: 20px; }
        h1 { font-size: 30px; color: #1a202c; margin-bottom: 10px; }
        .subtitle { font-size: 18px; color: #718096; margin-bottom: 24px; }
        .info-section { display: flex; flex-direction: column; gap: 16px; margin-bottom: 24px; }
        .info-item { display: flex; align-items: center; gap: 12px; background-color: #f7fafc; border-radius: 10px; padding: 10px 14px; font-size: 16px; color: #4a5568; }
        .message { margin-bottom: 16px; padding: 12px; border-radius: 10px; font-size: 15px; }
        .message.error { background-color: #fed7d7; color: #c53030; }
        .message.success { background-color: #c6f6d5; color: #2f855a; }
        form input { width: 100%; padding: 14px; margin-bottom: 18px; border-radius: 12px; border: 1px solid #e2e8f0; font-size: 16px; }
        form button, #authButton { width: 100%; padding: 14px; background-color: #667eea; color: white; font-size: 17px; font-weight: bold; border: none; border-radius: 12px; cursor: pointer; transition: transform 0.1s ease-in-out, background-color 0.2s; }
        form button:hover, #authButton:hover { transform: scale(1.03); background-color: #5a67d8; }
        .divider { height: 1px; background-color: #e2e8f0; margin: 28px 0; }
        .login-link { font-size: 16px; color: #718096; }
        .login-link a { color: #667eea; font-weight: bold; text-decoration: none; }
        .login-link a:hover { text-decoration: underline; }
        @media (max-width: 480px) {
          .card { padding: 24px 18px; }
          h1 { font-size: 26px; }
          .subtitle { font-size: 16px; }
          form input, form button, #authButton { font-size: 16px; }
          .info-item { font-size: 15px; }
        }
      `}</style>
      <div className="card">
        <div className="logo-container">
          <img src="/assets/image/logo.png" alt="Logo" />
        </div>
        <h1>Create Account</h1>
        <p className="subtitle">Secure biometric registration</p>

        <div className="info-section">
          <div className="info-item">
            <span className="icon">🛡️</span>
            <span>Biometric authentication required</span>
          </div>
          <div className="info-item">
            <span className="icon">⏳</span>
            <span>Admin approval needed</span>
          </div>
        </div>

        {error && <div className="message error">{error}</div>}
        {success && <div className="message success">{success}</div>}

        {!biometricSuccess && (
          <button id="authButton" onClick={handleBiometricAuth}>
            Authenticate with Biometrics
          </button>
        )}

        {biometricSuccess && (
          <form id="registrationForm" onSubmit={handleSubmit}>
            <input
              type="text"
              name="fullname"
              placeholder="Enter your full name..."
              required
              value={fullname}
              onChange={(e) => setFullname(e.target.value)}
            />
            <button type="submit">Register</button>
          </form>
        )}

        <div className="divider"></div>
        <p className="login-link">
          Already have an account? <a href="/userlog">Sign In</a>
        </p>
      </div>
    </div>
  );
}

export default UserReg;