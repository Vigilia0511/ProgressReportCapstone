import React, { useState } from "react";
import "../assets/css/styleforadminlogin.css"; // make sure this CSS file exists

function LoginPage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

const handleSubmit = async (e) => {
  e.preventDefault();
  setLoading(true);
  setError(false);

  const formData = new FormData(e.target);
  const username = formData.get("username");
  const password = formData.get("password");

  try {
    const response = await fetch("http://localhost/capstone_backend/login.php", {
      method: "POST",
      body: formData,
    });
    const result = await response.json();
    setLoading(false);

    if (result.success) {
      window.location.href = "/approval"; // or use React Router for navigation
    } else {
      setError(true);
    }
  } catch {
    setLoading(false);
    setError(true);
  }
};

  return (
    <div className="gradient-bg">
      <div className="login-container">
        {/* Logo at the top */}
        <div className="logo-wrapper">
          <img src="/assets/image/logo.png" alt="Logo" />
        </div>

        {/* Title Section */}
        <div className="title-section">
          <h2>Admin Portal</h2>
          <p>Sign in to your account</p>
        </div>

        {/* Error Message */}
        {error && (
          <div className="error-message">
            <p style={{ color: "red" }}>Invalid credentials. Please try again.</p>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit}>
          <label htmlFor="username">Admin ID</label>
          <input
            type="text"
            id="username"
            name="username"
            placeholder="Enter your admin ID"
            required
          />

          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            placeholder="Enter your password"
            required
          />

          <button type="submit" className="login-button">
            {loading ? "Signing In..." : "Sign In"}
          </button>
        </form>

        {/* Loading Indicator */}
        {loading && (
          <div className="loading-indicator">
            <div className="spinner"></div>
          </div>
        )}

        {/* Security Notice */}
        <div className="security-notice">
          <span role="img" aria-label="lock">
            🔒
          </span>
          <small>
            This is a secure admin area. All login attempts are monitored.
          </small>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
